/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package thrift

import (
	//"fmt"
	//"time"
	"bytes"
	"io"
	"io/ioutil"
	"net/http"
	"github.com/valyala/fasthttp"
	"net/url"
	"strconv"
)

// Default to using the shared http client. Library users are
// free to change this global client or specify one through
// THttpClientOptions.
var DefaultHttpClient *http.Client = http.DefaultClient

type THttpClient struct {
	client             *http.Client
	header             http.Header
	response           *http.Response
	fastclient             *fasthttp.Request
	fastheader             fasthttp.RequestHeader
	fastresponse           *fasthttp.Response
	Type             int
	url                *url.URL
	requestBuffer      *bytes.Buffer
	nsecConnectTimeout int64
	nsecReadTimeout    int64
	loop int64
	respReader *bytes.Reader
}

type THttpClientTransportFactory struct {
	options THttpClientOptions
	url     string
}

func (p *THttpClientTransportFactory) GetTransport(trans TTransport) (TTransport, error) {
	if trans != nil {
		t, ok := trans.(*THttpClient)
		if ok && t.url != nil {
			return NewTHttpClientWithOptions(t.url.String(), p.options)
		}
	}
	return NewTHttpClientWithOptions(p.url, p.options)
}

type THttpClientOptions struct {
	// If nil, DefaulTHttpClient is used
	FastHttp bool
}

func NewTHttpClientTransportFactory(url string) *THttpClientTransportFactory {
	return NewTHttpClientTransportFactoryWithOptions(url, THttpClientOptions{})
}

func NewTHttpClientTransportFactoryWithOptions(url string, options THttpClientOptions) *THttpClientTransportFactory {
	return &THttpClientTransportFactory{url: url, options: options}
}

func NewTHttpClientWithOptions(urlstr string, options THttpClientOptions) (TTransport, error) {
	parsedURL, err := url.Parse(urlstr)
	if err != nil {
		return nil, err
	}
	buf := make([]byte, 0, 2048)
	if options.FastHttp == false {
		client := DefaultHttpClient
	    httpHeader := map[string][]string{"Content-Type": {"application/x-thrift"}}
	    return &THttpClient{client: client, url: parsedURL, requestBuffer: bytes.NewBuffer(buf), header: httpHeader, Type: 1}, nil
	} else {
	    fastclient := fasthttp.AcquireRequest()
	    Header := fasthttp.RequestHeader{}
	    Header.SetContentType("application/x-thrift")
	    Header.Add("Content-Type", "application/x-thrift")
        Header.SetMethod("POST")
        fastresponse := fasthttp.AcquireResponse()
	    return &THttpClient{fastclient: fastclient, fastheader: Header, fastresponse: fastresponse, url: parsedURL, requestBuffer: bytes.NewBuffer(buf), loop: 0, respReader: bytes.NewReader(buf), Type: 2}, nil
	}
}

func NewTHttpClient(urlstr string) (TTransport, error) {
	return NewTHttpClientWithOptions(urlstr, THttpClientOptions{false})
}

func NewFastTHttpClient(urlstr string) (TTransport, error) {
	return NewTHttpClientWithOptions(urlstr, THttpClientOptions{true})
}

// Set the HTTP Header for this specific Thrift Transport
// It is important that you first assert the TTransport as a THttpClient type
// like so:
//
// httpTrans := trans.(THttpClient)
// httpTrans.SetHeader("User-Agent","Thrift Client 1.0")
func (p *THttpClient) SetHeader(key string, value string) {
	if key != "" && value != "" {
		if p.Type == 1 {
			p.header.Add(key, value)
		}else {
			p.fastheader.Add(key, value)
		}
	}
}

// Get the HTTP Header represented by the supplied Header Key for this specific Thrift Transport
// It is important that you first assert the TTransport as a THttpClient type
// like so:
//
// httpTrans := trans.(THttpClient)
// hdrValue := httpTrans.GetHeader("User-Agent")
func (p *THttpClient) GetHeader(key string) string {
	if p.Type == 1 {
		return p.header.Get(key)
	} else {
	    return string(p.fastheader.Peek(key))
	}
}

// Deletes the HTTP Header given a Header Key for this specific Thrift Transport
// It is important that you first assert the TTransport as a THttpClient type
// like so:
//
// httpTrans := trans.(THttpClient)
// httpTrans.DelHeader("User-Agent")
func (p *THttpClient) DelHeader(key string) {
	if p.Type == 1 {
		p.header.Del(key)
	} else {
	    p.fastheader.Del(key)
	}
}

func (p *THttpClient) Open() error {
	// do nothing
	return nil
}

func (p *THttpClient) IsOpen() bool {
	return p.fastresponse != nil || p.requestBuffer != nil
}

func (p *THttpClient) closeResponse() error {
	var err error
	if p.response != nil && p.response.Body != nil {
		io.Copy(ioutil.Discard, p.response.Body)

		err = p.response.Body.Close()
	}

	p.response = nil
	return err
}

func (p *THttpClient) Close() error {
	if p.requestBuffer != nil {
		p.requestBuffer.Reset()
	}
	return p.closeResponse()
}

func (p *THttpClient) Read(buf []byte) (int, error) {
	
	n, err := 0, io.EOF
	if p.Type == 1 {
		n, err = p.response.Body.Read(buf)
	} else {
        n, err = p.respReader.Read(buf)
    }
	if n > 0 && (err == nil || err == io.EOF) {
		return n, nil
	}
	return n, NewTTransportExceptionFromError(err)
}

func (p *THttpClient) ReadByte() (c byte, err error) {
	if p.Type == 1 {
		return readByte(p.response.Body)
	} else {
	    return readByte(p.respReader)
	}
}

func (p *THttpClient) Write(buf []byte) (int, error) {
	return p.requestBuffer.Write(buf)
}

func (p *THttpClient) WriteByte(c byte) error {
	return p.requestBuffer.WriteByte(c)
}

func (p *THttpClient) WriteString(s string) (n int, err error) {
	return p.requestBuffer.WriteString(s)
}

func (p *THttpClient) Flush() error {
	// Close any previous response body to avoid leaking connections.
	//if p.loop <= 2 {
	//    if p.IsOpen(){ p.closeResponse()}; p.loop += 1
	//}
	//:= time.Now()
	if p.Type == 1 {
	    p.closeResponse()
	    //:= time.Now()
	    req, err := http.NewRequest("POST", p.url.String(), p.requestBuffer)
	    //t.Println(time.Since(n))
	    if err != nil {
		    return NewTTransportExceptionFromError(err)
	    }
	    req.Header = p.header
	    //fmt.Println(p.header.Get("X-Line-Access"), p.requestBuffer)
	    //n := time.Now()
	    response, err := p.client.Do(req)
	    //fmt.Println(time.Since(n))
	    if err != nil {
		    return NewTTransportExceptionFromError(err)
	    }
	    if response.StatusCode != http.StatusOK {
		    // Close the response to avoid leaking file descriptors. closeResponse does
		    // more than just call Close(), so temporarily assign it and reuse the logic.
		    p.response = response
		    p.closeResponse()
    
		    // TODO(pomack) log bad response
		    return NewTTransportException(UNKNOWN_TRANSPORT_EXCEPTION, "HTTP Response code: "+strconv.Itoa(response.StatusCode))
	    }
	    p.response = response
	    //p.requestBuffer.Reset()
	} else {
	    defer func(){
		    fasthttp.ReleaseRequest(p.fastclient)
	        fasthttp.ReleaseResponse(p.fastresponse)
	    }()
	    p.fastclient.Header = p.fastheader
        p.fastclient.SetRequestURI(p.url.String())
        p.fastclient.SetBody(p.requestBuffer.Bytes())
    //    fmt.Println(p.requestBuffer.Bytes())
	    err := fasthttp.Do(p.fastclient, p.fastresponse)
	    if err != nil {
		    return NewTTransportExceptionFromError(err)
	    }
	    if p.fastresponse.StatusCode() != http.StatusOK {
		    // Close the response to avoid leaking file descriptors. closeResponse does
		    // more than just call Close(), so temporarily assign it and reuse the logic.
	        p.respReader.Reset(p.fastresponse.Body())
    
		    // TODO(pomack) log bad response
		    return NewTTransportException(UNKNOWN_TRANSPORT_EXCEPTION, "HTTP Response code: "+strconv.Itoa(p.fastresponse.StatusCode()))
	    }
	     
        p.respReader.Reset(p.fastresponse.Body())
        p.requestBuffer.Reset()
    }
	
	return nil
}

func (p *THttpClient) RemainingBytes() (num_bytes uint64) {
	len := int64(0)
	if p.Type == 1 {
		len = p.response.ContentLength
	} else {
	    len = p.respReader.Size()
	}
	if len >= 0 {
		return uint64(len)
	}

	const maxSize = ^uint64(27)
	return maxSize // the thruth is, we just don't know unless framed is used
}

// Deprecated: Use NewTHttpClientTransportFactory instead.
func NewTHttpPostClientTransportFactory(url string) *THttpClientTransportFactory {
	return NewTHttpClientTransportFactoryWithOptions(url, THttpClientOptions{})
}

// Deprecated: Use NewTHttpClientTransportFactoryWithOptions instead.
func NewTHttpPostClientTransportFactoryWithOptions(url string, options THttpClientOptions) *THttpClientTransportFactory {
	return NewTHttpClientTransportFactoryWithOptions(url, options)
}

// Deprecated: Use NewTHttpClientWithOptions instead.
func NewTHttpPostClientWithOptions(urlstr string, options THttpClientOptions) (TTransport, error) {
	return NewTHttpClientWithOptions(urlstr, options)
}

// Deprecated: Use NewTHttpClient instead.
func NewTHttpPostClient(urlstr string) (TTransport, error) {
	return NewTHttpClientWithOptions(urlstr, THttpClientOptions{})
}
